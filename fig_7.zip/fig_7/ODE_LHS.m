
function dydt = ODE_LHS(t, y, LHSmatrix, x, nsample)

% Ensure y is a column vector
y = y(:);

% Extract parameter values from LHSmatrix
a0 = LHSmatrix(x, 1);
b0 = LHSmatrix(x, 2);
w0 = LHSmatrix(x, 3);
d0 = LHSmatrix(x, 4);
w1 = LHSmatrix(x, 5);
d1 = LHSmatrix(x, 6);
w2 = LHSmatrix(x, 7);
d2 = LHSmatrix(x, 8);
a1 = LHSmatrix(x, 9);
b1 = LHSmatrix(x, 10);
e1 = LHSmatrix(x, 11);
w3 = LHSmatrix(x, 12);
d3 = LHSmatrix(x, 13);
c3 = LHSmatrix(x, 14);
b2 = LHSmatrix(x, 15);
e2 = LHSmatrix(x, 16);

% Ensure that parameters are scalars
if ~isscalar(a0) || ~isscalar(b0) || ~isscalar(w0) || ~isscalar(d0) || ...
   ~isscalar(w1) || ~isscalar(d1) || ~isscalar(w2) || ~isscalar(d2) || ...
   ~isscalar(a1) || ~isscalar(b1) || ~isscalar(e1) || ~isscalar(w3) || ...
   ~isscalar(d3) || ~isscalar(c3) || ~isscalar(b2) || ~isscalar(e2)
    error('One or more parameters are not scalars. Check LHSmatrix indexing.');
end

% Ensure that y has exactly 3 elements
if length(y) ~= 3
    error('y must be a column vector with exactly 3 elements.');
end

% Define the ODE system
dydt = [
    a0 * y(1) - b0 * y(1)^2 - (w0 * y(1) * y(2)) / (d0 + y(1));
    (w1 * y(1) * y(2)) / (d1 + y(1)) - (w2 * y(2) * y(3)) / (d2 + y(2)) - a1 * y(2) - (b1 * y(2)) / (e1 + y(1));
    (w3 * y(2) * y(3)) / (d3 + y(2)) - c3 * y(3) - (b2 * y(3)) / (e2 + y(2))
];

end


