%%Plots of the model simulations  
%% Sample size N

nsample=1000;

Parameter_settings_LHS;

a0_LHS = LHS_Call(a0-0.25, a0, a0+0.25, 0, nsample, 'unif');    
b0_LHS = LHS_Call(b0-0.003, b0, b0+0.003, 0, nsample, 'unif');  
w0_LHS = LHS_Call(w0-0.25, w0, w0+0.25, 0, nsample, 'unif');  
d0_LHS = LHS_Call(d0-0.25, d0, d0+0.25, 0, nsample, 'unif');   
w1_LHS = LHS_Call(w1-0.25, w1, w1+0.25, 0, nsample, 'unif');  
d1_LHS = LHS_Call(d1-0.25, d1, d1+0.25, 0, nsample, 'unif');  
w2_LHS = LHS_Call(w2-0.25, w2, w2+0.25, 0, nsample, 'unif');   
d2_LHS = LHS_Call(d2-0.25, d2, d2+0.25, 0, nsample, 'unif');  
a1_LHS = LHS_Call(a1-0.25, a1, a1+0.25, 0, nsample, 'unif');  
b1_LHS = LHS_Call(b1-0.25, b1, b1+0.25, 0, nsample, 'unif');  
e1_LHS = LHS_Call(e1-0.25, e1, e1+0.25, 0, nsample, 'unif');
w3_LHS = LHS_Call(w3-0.25, w3, w3+0.25, 0, nsample, 'unif');
d3_LHS = LHS_Call(d3-0.25, d3, d3+0.25, 0, nsample, 'unif');
c3_LHS = LHS_Call(c3-0.25, c3, c3+0.25, 0, nsample, 'unif');
b2_LHS = LHS_Call(b2-0.25, b2, b2+0.25, 0, nsample, 'unif');
e2_LHS = LHS_Call(e2-0.25, e2, e2+0.25, 0, nsample, 'unif');


LHSmatrix =[a0_LHS b0_LHS w0_LHS d0_LHS w1_LHS d1_LHS w2_LHS d2_LHS a1_LHS b1_LHS e1_LHS w3_LHS d3_LHS c3_LHS b2_LHS e2_LHS];
          

for x=1:nsample %Run solution x times choosing different values
    f=@ODE_LHS;
    x
    LHSmatrix(x,:)
    options = odeset('RelTol',1e-12,'AbsTol',1e-12);
    [t,y]=ode45(@(t,y)f(t,y,LHSmatrix,x,nsample),tspan,y0,[]);
    A=[t y]; % [time y]
    plot(t,y(:,1),'LineWidth',1)
    xlabel('Time (Days)','FontWeight','bold','FontSize',14)
    ylabel('v_1','FontWeight','bold','FontSize',14)
    ax = gca; 
    ax.FontSize = 14; 
    ax.FontWeight = 'bold';
    hold on
end
