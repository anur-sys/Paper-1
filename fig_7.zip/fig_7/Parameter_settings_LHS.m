a0 =  2;
b0 =  0.05;
w0 =  1;
d0 =  10;
w1 =  1.971;
d1 =  10;
w2 =  1.5;
d2 =  10;
a1 =  0.971;
b1 =  0.294;
e1 =  10;
w3 =  1.993;
d3 =  20;
c3 =  0.693;
b2 =  0.134;
e2 =  20;


% Parameter Labels 
PRCC_var={'a_{0}','b_{0}','w_{0}','d_{0}','w_{1}','d_{1}','w_{2}','d_{2}','a_{1}','b_{1}','e_{1}','w_{3}','d_{3}','c_{3}','b_{2}','e_{2}'};



%% TIME SPAN OF THE SIMULATION
t_end = 100; % length of the simulationss
tspan =(0:0.01:t_end);   % time points where the output is calculated
%time_points=[2000 4000]; % time points of interest for the US analysis
%time_points=[1 10 20 30 40 50 60 70 80 90 100 110 120 130 140 150 160 170 180 190 200 210 220 230 240 250 260 270 280 290 300 310 320];
time_points=[100];


% INITIAL CONDITION FOR THE ODE MODEL
v10 = 35.24123;
v20 = 10.76461;
v30 = 7.72218;

y0=[v10, v20, v30];

% Variables Labels
y_var_label={'v_1','v_2','v_3'};